package Lab1;

public class index {

}
