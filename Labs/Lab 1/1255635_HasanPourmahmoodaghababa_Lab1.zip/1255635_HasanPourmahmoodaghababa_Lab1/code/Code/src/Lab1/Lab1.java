package Lab1;
import org.lemurproject.galago.core.index.LengthsReader;
import org.lemurproject.galago.core.index.disk.DiskLengthsReader;
import org.lemurproject.galago.core.retrieval.Retrieval;
import org.lemurproject.galago.core.retrieval.RetrievalFactory;
import org.lemurproject.galago.core.retrieval.iterator.LengthsIterator;
import org.lemurproject.galago.core.retrieval.processing.ScoringContext;
import org.lemurproject.galago.core.retrieval.query.Node;
import org.lemurproject.galago.core.retrieval.query.StructuredQuery;
import org.lemurproject.galago.core.index.stats.FieldStatistics;
import org.lemurproject.galago.core.index.stats.NodeStatistics;
import org.lemurproject.galago.utility.Parameters;
import org.lemurproject.galago.core.parse.Document;
import org.lemurproject.galago.core.parse.Tag;
import java.util.Set;
import java.util.TreeSet;
import java.io.File;
public class Lab1 {
	
	public static void main(String[] args) {
		try {
			String pathIndexBase = "/Users/hasan/Desktop/CS_6550_galago_tutorial/index";  //path to index
			Retrieval r = RetrievalFactory.instance(pathIndexBase, Parameters.create());
			
			
			
// Extracting document statistics
	        Node n = new Node();
		    n.setOperator("lengths");
	        n.getNodeParameters().set("part", "lengths");
		    FieldStatistics stat = r.getCollectionStatistics(n);   
		    //System.out.println(stat);
		    long documentCount = stat.documentCount; // number of documents in the corpus
		    long minLength = stat.minLength; // the length of the document with the minimum length in text field
		    System.out.println("Number of Documents: " + documentCount);
	        System.out.println("Minimal Length Document: " + minLength);
	        System.out.println(); 
	        

	        
	        	        
// Extracting document statistics in text filed	        
		    String field = "text";
		    Node fieldNode = StructuredQuery.parse("#lengths:" + field + ":part=lengths()");
		    FieldStatistics fieldStats = r.getCollectionStatistics(fieldNode); 
		    //System.out.println(fieldStats);
		    long max_length_field = fieldStats.maxLength; // same as maxLength ???
		    long min_length_field = fieldStats.minLength; // same as minLength ???
		    long corpusLength = fieldStats.collectionLength; // total number of words in text field in whole data
		    long corpusCount = fieldStats.documentCount; // same as document count
		    System.out.println("Minimal length in text field: " + min_length_field);
		    System.out.println("Mimal length in text field: " + max_length_field);
		    System.out.println("Total number of words in text field in whole data: " + corpusLength);
		    System.out.println("Number of Documents: " + corpusCount);
		    System.out.println();		    
		    
		    
      
// Extracting number of unique words			
			Document.DocumentComponents dc = new Document.DocumentComponents(false, false, true);
			Set<String> unique_vocab = new TreeSet<>();
			for(long docid = stat.firstDocId; docid <= stat.lastDocId; docid++) {
				Document doc = r.getDocument(r.getDocumentName(docid), dc);
				for (Tag tag : doc.tags) { // doc.tags return a list of document fields
					if (tag.name.equals(field)) { 
						// keep a copy of the start and end position of the field in the document.
						for (int position = tag.begin; position < tag.end; position++) {
							String term = doc.terms.get(position);
							unique_vocab.add(term);
						}
					}
				}				
			}
			System.out.println("Number of Unique Words: " + unique_vocab.size());
			System.out.println();
			
			

// Finding the id the longest document 		    
		    File fileLength = new File(new File( pathIndexBase ), "lengths");
		    LengthsReader indexLength = new DiskLengthsReader(fileLength.getAbsolutePath());
		    LengthsIterator iterator = (LengthsIterator) indexLength.getIterator(fieldNode);
			ScoringContext sc = new ScoringContext();
			int length_max = 1;
			long docno_max = sc.document;
			String id_max = "";
			while (!iterator.isDone()) {
				sc.document = iterator.currentCandidate();
				String docno = r.getDocumentName((long) sc.document);
				int length = iterator.length(sc);
				if (length >= length_max) {
					length_max = length;
					id_max = docno;
					docno_max = sc.document;
				}
				iterator.movePast(iterator.currentCandidate());
			}
			System.out.println("Longest Document id: " + id_max);
			System.out.println("Longest Document Length: " + length_max);
			System.out.println("Longest Document Doc Number: " + docno_max);
			indexLength.close();
			System.out.println();
			
			

// Extracting term statistics.
            String query = "computer";
	        Node node = StructuredQuery.parse( "#text:" + query + ":part=field." + field + "()" );
	        node.getNodeParameters().set("queryType", "count");
	        node = r.transformQuery(node, Parameters.create());
            NodeStatistics stat_node = r.getNodeStatistics(node);
            //System.out.println(stat_node);
            long nodeDocCount = stat_node.nodeDocumentCount;
            long maxCount = stat_node.maximumCount;
            long nodeFrequency = stat_node.nodeFrequency;
	        System.out.println("The number of documents containing term '" + query +"': "+ nodeDocCount);
		 // nodeDocCount Count: the number of documents containing that query
	        System.out.println("The frequency of query in the document that has the maximum number of term '" + query +"': "+ maxCount);
		 // maxCount: the frequency number of query in the document that has the biggest number of that query 
	        System.out.println("Total number of query frequency in the whole corpus: "+ nodeFrequency);
		 // nodeFrequency: total number of query frequency in the whole corpus 

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
