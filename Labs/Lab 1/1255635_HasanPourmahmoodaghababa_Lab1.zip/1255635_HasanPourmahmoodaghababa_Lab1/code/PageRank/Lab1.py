# Lab 1

# Question 1: PageRank
# 
# <img src="Graph.png" style="width:450px; height=300px"/>

import numpy as np
from scipy import linalg as LA
import time

'''
The structure of Web is like a graph, where each page is a node and each link 
is a directed edge from one node to another. Figure 1 shows an example graph 
with 10 pages. Implement the PageRank algorithm and report the PageRank scores 
for each node (2 points per node) in the graph. Assume that the random jump 
probability is equal to 0.1.
'''


# transition matrix
M = np.zeros((10,10))
M[0][[1,4]] = 0.5
M[1][[0,7]] = 0.5
M[2][[5,8,9]] = 0.33
M[3][[4,6]] = 0.5
M[4][[0,3]] = 0.5
M[5][[3,4]] = 0.5
M[6][[1,4]] = 0.5
M[7][6] = 1
M[8][[5,9]] = 0.5
M[9][3] = 1
print(M)



def PageRank(M, alpha, probs, eps):
    '''
    parameters:
        M: transition matrix
        alpha: random jump probability
        probs: initial probability distribution over nodes (usually uniform distribution)
        eps: error tolorence to get convergence
    '''
    start_time = time.time()
    count = 1
    n = len(M)
    I = np.ones((n,n)) # all ones matrix of shape (n,n)
    trans_matrix = (1 - alpha) * M + (alpha/n) * I
    prev_scores = probs + 0 
    cur_scores = trans_matrix.T @ prev_scores
    cur_scores = cur_scores/np.sum(cur_scores)
    while LA.norm(cur_scores - prev_scores) > eps:
        prev_scores = cur_scores + 0
        cur_scores = trans_matrix.T @ prev_scores
        cur_scores = cur_scores/np.sum(cur_scores)
        count += 1
    print(f"Number of iterations: {count}")
    print(f"total_time: {time.time() - start_time}")
    return cur_scores, np.argsort(cur_scores)


print(PageRank(M, alpha=0.1, probs=np.zeros(10)+0.1, eps=1e-5))

print(PageRank(M, alpha=0.1, probs=np.zeros(10)+0.1, eps=1e-6))
