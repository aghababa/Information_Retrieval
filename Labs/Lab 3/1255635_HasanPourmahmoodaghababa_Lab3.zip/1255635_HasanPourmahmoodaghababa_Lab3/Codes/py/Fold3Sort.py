import numpy as np

path = '/Users/hasan/Desktop/Anaconda/IR-Fold3/'
doc = open(path+'train.txt').read().split('\n')

print(len(doc))
print(doc[0][:20])
print(doc[-2][:11])


docToSortedIdx = []
for j in range(len(doc)-1):
	a = ''
	for i in range(5):
		b = doc[j][6:11][i]
		if b.isnumeric():
			a = a + b
		else:
			break
	docToSortedIdx.append(int(a))
    
docSortedIdx = np.argsort(docToSortedIdx)


docSorted = []
for i in range(len(doc)-1):
    docSorted.append(doc[docSortedIdx[i]])
docSorted.append(doc[-1])
print(len(docSorted))


ds = []
for j in range(len(docSorted)-1):
	a = ''
	for i in range(5):
		b = docSorted[j][6:11][i]
		if b.isnumeric():
			a = a + b
		else:
			break
	ds.append(int(a))
    
print(sum(ds != np.sort(ds)))


with open('train_sorted.txt', 'w') as f:
    for i in range(len(doc)-1):
        f.write(docSorted[i])
        f.write('\n')
    f.close()


print)open(path+'train_sorted.txt').read().split('\n')[:3])

