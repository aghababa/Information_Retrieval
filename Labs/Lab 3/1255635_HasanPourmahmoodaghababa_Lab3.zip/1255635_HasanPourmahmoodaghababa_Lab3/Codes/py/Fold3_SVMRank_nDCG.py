import numpy as np
import time
import math


path = '/Users/hasan/Downloads/MSLR-WEB10K/Fold3/'
doc = open(path+'test.txt').read().split('\n')

print(len(doc))


s_time = time.time()

relevance_labels = []
qids = []

for i in range(len(doc)-1):
    d_list = doc[i].split()
    relevance_labels.append(int(d_list[0]))
    qids.append(int(d_list[1][4:]))
    
relevance_labels = np.array(relevance_labels)
qids = np.array(qids)

print(time.time() - s_time)


predictions = np.array(list(map(float, 
                       np.array(open(path+'test_predictions').read().split('\n'))[:-1])))
print(predictions[:5])


print(len(set(qids)))


k = 5
nDCG_list = []
for i in list(set(qids)):
    I = np.where(qids == i)[0]
    log_list = np.array([1/math.log(j, 2) for j in range(2, len(I[:k])+2)])
    J = np.argsort(predictions[I])[::-1]
    DCG_i = relevance_labels[J][:k].dot(log_list)
    iDCG = np.sort(relevance_labels[I])[::-1][:k].dot(log_list)
    if iDCG != 0:
        nDCG_list.append(DCG_i/iDCG)

print(np.mean(nDCG_list))

print(len(nDCG_list))





